$projectPath = "d:\Hafizh\Matra\Web Nanorobotic\Template cobaan\kiden"

# Correct footer HTML content
$correctFooter = @'
   <footer>
      <div class="it-footer-wrap p-relative z-index fix">
         <div class="it-footer-bg">
            <img alt="" loading="lazy" src="assets/img/footer/bg-1-1.png" />
         </div>
         <!-- footer-area-start -->
         <div class="it-footer-area pt-120 pb-70">
            <div class="container">
               <div class="row">
                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-delay=".3s"
                     data-wow-duration=".9s">
                     <div class="it-footer-widget footer-col-1">
                        <div class="it-footer-logo pb-20">
                           <a href="index.html">
                              <img alt="" loading="lazy" src="assets/img/logo/logo-white.png" />
                           </a>
                        </div>
                        <div class="it-footer-text pb-15">
                           <p>Untuk mendapatkan berita terbaru tentang Kami, dapat mengakses media sosial kami</p>
                        </div>
                        <div class="it-footer-social">
                           <a href="https://www.instagram.com/nano_robotic?utm_source=qr&amp;igsh=MTQ2ZW1nd3BkZGs5YQ=="><i class="fab fa-instagram"></i></a>
                           <a href="https://youtube.com/@nanorobotic470?si=ywGjojMn23cnjaM5"><i class="fab fa-youtube"></i></a>
                           <a href="https://www.tiktok.com/@nano_robotic"><i class="fab fa-tiktok"></i></a>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-delay=".5s"
                     data-wow-duration=".9s">
                     <div class="it-footer-widget footer-col-2">
                        <h4 class="it-footer-title">QUICK LINKS</h4>
                        <div class="it-footer-list-2">
                           <ul>
                              <li><a href="index.html">Beranda</a></li>
                              <li><a href="about-us.html">Tentang Kami</a></li>
                              <li><a href="program.html">Kelas</a></li>
                              <li><a href="shop.html">Retail</a></li>
                              <li><a href="blog.html">Artikel</a></li>
                              <li><a href="https://maps.app.goo.gl/D1gbso1EWnZyNig5A">Lokasi</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-delay=".7s"
                     data-wow-duration=".9s">
                     <div class="it-footer-widget footer-col-3">
                        <h4 class="it-footer-title">Support</h4>
                        <div class="it-footer-list-2">
                           <ul>
                              <li><a href="https://api.whatsapp.com/send/?phone=6287790005689&amp;text&amp;type=phone_number&amp;app_absent=0">Help Center</a></li>
                              <li><a href="https://api.whatsapp.com/send/?phone=6287790005689&amp;text&amp;type=phone_number&amp;app_absent=0">Kontak Kami</a></li>
                              <li><a href="https://api.whatsapp.com/send/?phone=6287790005689&amp;text&amp;type=phone_number&amp;app_absent=0">FAQ</a></li>
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-delay=".8s"
                     data-wow-duration=".9s">
                     <div class="it-footer-widget footer-col-4">
                        <h4 class="it-footer-title">Get In Touch</h4>
                        <div class="it-footer-contact">
                           <ul>
                              <li>
                                 <span><svg fill="none" height="19" viewbox="0 0 18 19" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M17.7071 0.125923C17.6174 0.0674959 17.5144 0.032423 17.4077 0.0238908C17.3009 0.0153586 17.1937 0.0336376 17.0958 0.0770671L11.9717 2.35466L6.25423 0.0674246C6.17445 0.0355282 6.08908 0.0199476 6.00318 0.0216038C5.91728 0.02326 5.83258 0.0421193 5.75409 0.0770671L0.381849 2.46459C0.268182 2.51509 0.171606 2.59747 0.103829 2.70176C0.0360514 2.80605 -1.5781e-05 2.92777 5.17987e-09 3.05215V17.3786C-1.35891e-05 17.4857 0.0267332 17.5911 0.0778106 17.6852C0.128888 17.7793 0.202677 17.8592 0.292474 17.9176C0.382272 17.976 0.485231 18.011 0.591999 18.0195C0.698767 18.0279 0.805959 18.0096 0.903838 17.9661L6.02794 15.6885L11.7454 17.9758C11.8252 18.0073 11.9106 18.0227 11.9964 18.0211C12.0823 18.0194 12.167 18.0007 12.2455 17.9661L17.6178 15.5786C17.7314 15.5281 17.828 15.4457 17.8958 15.3414C17.9636 15.2371 17.9996 15.1154 17.9996 14.991V0.664626C17.9996 0.55758 17.9728 0.45224 17.9217 0.358167C17.8706 0.264093 17.7969 0.184263 17.7071 0.125923ZM6.65793 1.61411L11.3417 3.488V16.4291L6.65793 14.5552V1.61411ZM1.28569 3.47L5.37224 1.65396V14.5751L1.28569 16.3892V3.47ZM16.7139 14.5732L12.6274 16.3892V3.47L16.7139 1.65396V14.5732Z" fill="currentcolor"></path></svg></span>
                                 <a href="https://maps.app.goo.gl/6QfeAGRcxc1uLByt7" target="_blank">Jl. Cempaka Blok Z3 No. 1, Taman Cimanggu, Tanah Sereal Kota Bogor, Bogor 16164 Jawa Barat - Indonesia</a>
                              </li>
                              <li>
                                 <span><svg fill="none" height="19" viewbox="0 0 18 19" width="18" xmlns="http://www.w3.org/2000/svg"><path d="M14.2126 11.1718C13.8441 10.7881 13.3996 10.583 12.9285 10.583C12.4612 10.583 12.013 10.7843 11.6293 11.168L10.4288 12.3647C10.33 12.3115 10.2312 12.2621 10.1362 12.2128C9.99947 12.1444 9.8703 12.0798 9.76013 12.0114C8.63562 11.2972 7.61368 10.3664 6.63353 9.16214C6.15866 8.5619 5.83954 8.05663 5.6078 7.54376C5.91932 7.25883 6.20804 6.96251 6.48917 6.67758C6.59554 6.57121 6.70192 6.46104 6.80829 6.35466C7.60608 5.55687 7.60608 4.52353 6.80829 3.72574L5.77115 2.6886C5.65338 2.57084 5.53182 2.44927 5.41785 2.3277C5.1899 2.09216 4.95057 1.84902 4.70363 1.62108C4.33512 1.25637 3.89444 1.06262 3.43096 1.06262C2.96747 1.06262 2.51919 1.25637 2.13929 1.62108C2.13549 1.62488 2.13549 1.62488 2.13169 1.62868L0.840021 2.93174C0.353746 3.41802 0.0764168 4.01067 0.0156324 4.69829C-0.0755442 5.8076 0.251172 6.84094 0.501908 7.51717C1.11735 9.17734 2.03671 10.7159 3.40816 12.3647C5.07213 14.3516 7.07422 15.9206 9.36123 17.0261C10.235 17.4402 11.4013 17.9303 12.7044 18.0139C12.7842 18.0177 12.8677 18.0215 12.9437 18.0215C13.8213 18.0215 14.5583 17.7062 15.1358 17.0793C15.1396 17.0717 15.1471 17.0679 15.1509 17.0603C15.3485 16.821 15.5764 16.6044 15.8158 16.3727C15.9791 16.2169 16.1463 16.0536 16.3096 15.8826C16.6858 15.4913 16.8833 15.0354 16.8833 14.5682C16.8833 14.0971 16.682 13.645 16.2983 13.2651L14.2126 11.1718ZM15.5726 15.1722C15.5688 15.1722 15.5688 15.176 15.5726 15.1722C15.4245 15.3318 15.2725 15.4761 15.1092 15.6357C14.8622 15.8712 14.6115 16.1182 14.3759 16.3955C13.9922 16.8058 13.5402 16.9995 12.9475 16.9995C12.8905 16.9995 12.8297 16.9995 12.7728 16.9957C11.6444 16.9236 10.5959 16.4829 9.80952 16.1068C7.65927 15.0658 5.77115 13.588 4.20216 11.7151C2.90669 10.1537 2.04051 8.71006 1.46686 7.16006C1.11355 6.2141 0.984384 5.47709 1.04137 4.78187C1.07936 4.33738 1.25032 3.96888 1.56563 3.65356L2.8611 2.35809C3.04725 2.18333 3.2448 2.08836 3.43855 2.08836C3.67789 2.08836 3.87164 2.23272 3.99321 2.35429C3.99701 2.35809 4.00081 2.36189 4.00461 2.36569C4.23635 2.58223 4.45669 2.80637 4.68843 3.04571C4.8062 3.16728 4.92777 3.28885 5.04934 3.41422L6.08647 4.45135C6.48917 4.85405 6.48917 5.22635 6.08647 5.62905C5.9763 5.73922 5.86993 5.84939 5.75976 5.95577C5.44064 6.28248 5.13672 6.5864 4.8062 6.88273C4.7986 6.89033 4.79101 6.89413 4.78721 6.90172C4.46049 7.22844 4.52128 7.54756 4.58966 7.7641C4.59346 7.7755 4.59726 7.7869 4.60106 7.79829C4.87079 8.45173 5.25069 9.06717 5.82814 9.80038L5.83194 9.80418C6.88047 11.0958 7.98599 12.1026 9.20547 12.8738C9.36123 12.9726 9.52079 13.0523 9.67275 13.1283C9.80952 13.1967 9.93868 13.2613 10.0489 13.3297C10.0641 13.3373 10.0792 13.3487 10.0944 13.3563C10.2236 13.4209 10.3452 13.4512 10.4705 13.4512C10.7859 13.4512 10.9834 13.2537 11.048 13.1891L12.3473 11.8898C12.4764 11.7607 12.6816 11.6049 12.9209 11.6049C13.1565 11.6049 13.3502 11.7531 13.468 11.8822C13.4718 11.886 13.4718 11.886 13.4756 11.8898L15.5688 13.9831C15.9601 14.3706 15.9601 14.7695 15.5726 15.1722Z" fill="currentcolor"></path><path d="M9.71512 4.30317C10.7105 4.47033 11.6146 4.94141 12.3365 5.66322C13.0583 6.38504 13.5255 7.28921 13.6965 8.28455C13.7383 8.53529 13.9548 8.71004 14.2018 8.71004C14.2322 8.71004 14.2588 8.70624 14.2891 8.70244C14.5703 8.65686 14.7564 8.39092 14.7108 8.1098C14.5057 6.90551 13.9358 5.80759 13.0659 4.93761C12.1959 4.06763 11.098 3.49778 9.89368 3.29263C9.61255 3.24704 9.35042 3.4332 9.30103 3.71053C9.25164 3.98785 9.434 4.25759 9.71512 4.30317Z" fill="currentcolor"></path><path d="M17.9663 7.96167C17.6282 5.97858 16.6936 4.17404 15.2576 2.73801C13.8216 1.30198 12.017 0.367417 10.0339 0.0293033C9.75661 -0.020084 9.49448 0.169867 9.44509 0.447196C9.39951 0.728324 9.58566 0.990457 9.86679 1.03984C11.6371 1.33997 13.2517 2.17955 14.5358 3.45982C15.8199 4.74389 16.6556 6.35848 16.9558 8.12882C16.9976 8.37956 17.2141 8.55431 17.461 8.55431C17.4914 8.55431 17.518 8.55052 17.5484 8.54672C17.8257 8.50493 18.0157 8.239 17.9663 7.96167Z" fill="currentcolor"></path></svg></span>
                                 <a href="https://api.whatsapp.com/send/?phone=6287790005689&amp;text&amp;type=phone_number&amp;app_absent=0">0877-9000-5689</a>
                              </li>
                              <li>
                                 <span><svg fill="none" height="19" viewbox="0 0 22 19" width="22" xmlns="http://www.w3.org/2000/svg"><path d="M16.6632 5.30337C16.4965 5.13536 16.2252 5.13425 16.0571 5.30092C15.8891 5.46764 15.888 5.73902 16.0547 5.90706L16.0573 5.90972C16.1408 5.99385 16.2501 6.03577 16.3596 6.03577C16.4688 6.03577 16.5782 5.99402 16.6621 5.91079C16.8302 5.74407 16.83 5.47141 16.6632 5.30337Z" fill="currentcolor"></path><path d="M21.8177 10.4573L17.8372 6.47672C17.6698 6.3094 17.3984 6.3094 17.231 6.47672C17.0637 6.64408 17.0637 6.91546 17.231 7.08286L20.391 10.2428H12.8555C12.2304 10.2428 11.7219 9.73428 11.7219 9.10919V1.57372L14.7726 4.62444C14.94 4.79176 15.2114 4.79176 15.3788 4.62444C15.5461 4.45708 15.5461 4.1857 15.3788 4.0183L11.5074 0.146973C11.3401 -0.0203451 11.0687 -0.0203451 10.9013 0.146973L4.06888 6.97953C3.90152 7.14689 3.90152 7.41827 4.06888 7.58568L14.3792 17.896C14.4596 17.9763 14.5686 18.0215 14.6823 18.0215C14.7959 18.0215 14.9049 17.9763 14.9853 17.896L21.8178 11.0634C21.8981 10.983 21.9433 10.874 21.9433 10.7604C21.9433 10.6467 21.8981 10.5377 21.8177 10.4573ZM10.8648 1.39581V6.85404H5.40657L10.8648 1.39581ZM14.2537 16.5582L5.40657 7.71116H10.8648V9.10919C10.8648 10.2069 11.7579 11.1 12.8556 11.1H14.2537V16.5582ZM15.1108 16.5582V11.1H20.569L15.1108 16.5582Z" fill="currentcolor"></path><path d="M2.94139 8.93579H0.428581C0.191876 8.93579 0 9.12771 0 9.36437C0 9.60103 0.191876 9.79295 0.428581 9.79295H2.94139C3.1781 9.79295 3.36997 9.60108 3.36997 9.36437C3.36997 9.12771 3.1781 8.93579 2.94139 8.93579Z" fill="currentcolor"></path><path d="M4.21894 8.93579H4.21252C3.97581 8.93579 3.78394 9.12771 3.78394 9.36437C3.78394 9.60103 3.97581 9.79295 4.21252 9.79295H4.21894C4.45565 9.79295 4.64753 9.60103 4.64753 9.36437C4.64753 9.12771 4.45565 8.93579 4.21894 8.93579Z" fill="currentcolor"></path><path d="M1.80139 4.43579H0.429801C0.193096 4.43579 0.0012207 4.62771 0.0012207 4.86437C0.0012207 5.10103 0.193096 5.29295 0.429801 5.29295H1.80139C2.03809 5.29295 2.22997 5.10103 2.22997 4.86437C2.22997 4.62771 2.03809 4.43579 1.80139 4.43579Z" fill="currentcolor"></path><path d="M4.8213 4.43579H3.20007C2.96336 4.43579 2.77148 4.62771 2.77148 4.86437C2.77148 5.10103 2.96336 5.29295 3.20007 5.29295H4.8213C5.05801 5.29295 5.24988 5.10103 5.24988 4.86437C5.24988 4.62771 5.05801 4.43579 4.8213 4.43579Z" fill="currentcolor"></path><path d="M5.7551 11.2928H3.35509C3.11839 11.2928 2.92651 11.4848 2.92651 11.7214C2.92651 11.9581 3.11839 12.15 3.35509 12.15H5.7551C5.99181 12.15 6.18368 11.9581 6.18368 11.7214C6.18368 11.4848 5.99177 11.2928 5.7551 11.2928Z" fill="currentcolor"></path><path d="M7.62851 14.0358H1.58556C1.34886 14.0358 1.15698 14.2277 1.15698 14.4643C1.15698 14.701 1.34886 14.8929 1.58556 14.8929H7.62851C7.86521 14.8929 8.05709 14.701 8.05709 14.4643C8.05709 14.2277 7.86521 14.0358 7.62851 14.0358Z" fill="currentcolor"></path></svg></span>
                                 <a href="mailto:nano.idrobotic@gmail.com">nano.idrobotic@gmail.com</a>
                              </li>
                              <li>
                                 <span><svg fill="none" height="19" viewbox="0 0 18 19" width="18" xmlns="http://www.w3.org/2000/svg"><path clip-rule="evenodd" d="M11.2929 6.31437C11.6834 5.92385 12.3166 5.92385 12.7071 6.31437L17.7071 11.3144C18.0976 11.7049 18.0976 12.3381 17.7071 12.7286L12.7071 17.7286C12.3166 18.1191 11.6834 18.1191 11.2929 17.7286C10.9024 17.3381 10.9024 16.7049 11.2929 16.3144L15.5858 12.0215L11.2929 7.72859C10.9024 7.33809 10.9024 6.70491 11.2929 6.31437Z" fill="currentcolor" fill-rule="evenodd"></path><path clip-rule="evenodd" d="M1 0.0214844C1.55228 0.0214844 2 0.469205 2 1.02149V8.0215C2 8.8171 2.31607 9.5802 2.87868 10.1428C3.44129 10.7054 4.20436 11.0215 5.00001 11.0215H17C17.5523 11.0215 18 11.4692 18 12.0215C18 12.5738 17.5523 13.0215 17 13.0215H5.00001C3.67392 13.0215 2.40215 12.4947 1.46447 11.557C0.526781 10.6194 0 9.3476 0 8.0215V1.02149C0 0.469205 0.447721 0.0214844 1 0.0214844Z" fill="currentcolor" fill-rule="evenodd"></path></svg></span>
                                 <a href="https://api.whatsapp.com/send/?phone=6287790005689&amp;text&amp;type=phone_number&amp;app_absent=0">More Information</a>
                              </li>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!-- footer-area-end -->
      </div>
      <!-- copy-right area start -->
      <div class="it-copyright-area theme-bg it-copyright-height">
         <div class="container">
            <div class="row">
               <div class="col-12 wow itfadeUp" data-wow-delay=".3s" data-wow-duration=".9s">
                  <div class="it-copyright-text text-center">
                     <p>© Copyright 2025 by Nanorobotic</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- copy-right area end -->
   </footer>
'@

# Files to fix
$filesToFix = @(
    "404.html",
    "blog-details.html",
    "blog-sidebar.html",
    "cart.html",
    "checkout.html",
    "faq.html",
    "gallery.html",
    "instructor-registration.html",
    "login.html",
    "price.html",
    "program-details.html",
    "register.html",
    "shop-details.html",
    "student-registration.html",
    "teacher-2.html",
    "teacher-details.html",
    "outline web\404.html",
    "outline web\faq.html",
    "outline web\gallery.html"
)

Write-Host "Starting footer replacement..."
$count = 0

foreach ($file in $filesToFix) {
    $filePath = Join-Path $projectPath $file
    if (Test-Path $filePath) {
        $content = Get-Content $filePath -Raw -Encoding UTF8
        
        # Pattern to match footer with any whitespace
        $pattern = '(?s)\s*<footer>.*?</footer>'
        
        if ($content -match $pattern) {
            $newContent = $content -replace $pattern, ("`r`n" + $correctFooter)
            $newContent | Set-Content $filePath -Encoding UTF8 -NoNewline
            $count++
            Write-Host "Fixed: $file"
        } else {
            Write-Host "No footer pattern found in: $file" -ForegroundColor Yellow
        }
    } else {
        Write-Host "NOT FOUND: $file" -ForegroundColor Red
    }
}

Write-Host "`nCompleted! Fixed $count files."
